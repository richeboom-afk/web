import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import { AgGridReact } from 'ag-grid-react';
import * as XLSX from "xlsx";

// --- AG GRID MODULES ---
import { ModuleRegistry, AllCommunityModule } from 'ag-grid-community'; 
import type { ColDef, ColGroupDef, IRowNode } from 'ag-grid-community';
import "ag-grid-community/styles/ag-grid.css"; 
import "ag-grid-community/styles/ag-theme-balham.css"; 

ModuleRegistry.registerModules([ AllCommunityModule ]);

const SIGNAL_TYPES = ['VID', 'AUD', 'CTRL', 'DATA', 'POWER', 'RF', 'FIBER', 'OTHER'];

const GRID_STYLES = `
  html, body, #root { margin: 0; padding: 0; height: 100%; width: 100%; overflow: hidden; font-family: "Segoe UI", sans-serif; background-color: #f0f0f0; }
  .ag-icon, .ag-header-icon, .ag-icon-menu, .ag-icon-filter, .ag-icon-asc, .ag-icon-desc, .ag-icon-none { display: none !important; }
  .ag-theme-balham .ag-header-cell-label { justify-content: center !important; } 
  .ag-theme-balham .ag-cell { border-right: none !important; border-bottom: 1px solid #d9d9d9 !important; text-align: center; } 
  .a-side-header { background-color: #A0CCFF !important; } 
  .b-side-header { background-color: #B0FFB0 !important; } 
  .label-preview-container { background-color: #fff; border: 1px solid #000; padding: 12px; border-radius: 4px; font-family: 'Consolas', monospace; font-weight: bold; font-size: 13px; line-height: 1.2; height: 100px; overflow: hidden; }
  .sidebar-section { margin-bottom: 25px; }
  .sidebar-section h4 { border-bottom: 1px solid #ddd; padding-bottom: 5px; margin-bottom: 10px; font-size: 0.95rem; color: #333; }
  .checkbox-label { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; cursor: pointer; margin-bottom: 8px; color: #444; }
  .btn { padding: 6px 14px; border-radius: 4px; border: 1px solid #ccc; cursor: pointer; font-weight: 600; font-size: 0.85rem; }
  .btn-primary { background-color: #007bff; color: white; border-color: #0069d9; }
  .btn-dark { background-color: #444; color: white; border: 1px solid #666; }
  .btn-danger { background-color: #dc3545; color: white; border-color: #bd2130; }

  /* Connection Path Visualizer Styles */
  .path-visualizer { display: flex; align-items: center; gap: 15px; background: #222; padding: 5px 20px; border-radius: 6px; border: 1px solid #444; margin: 0 20px; flex: 1; max-width: 600px; height: 45px; }
  .path-node { display: flex; flex-direction: column; align-items: center; min-width: 80px; }
  .node-label { font-size: 10px; color: #aaa; text-transform: uppercase; letter-spacing: 1px; }
  .node-value { font-size: 13px; color: #fff; font-weight: bold; }
  .path-line-container { flex: 1; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
  .path-line { width: 100%; height: 2px; background: #555; position: relative; }
  .path-line::before, .path-line::after { content: ''; position: absolute; width: 6px; height: 6px; background: #007bff; border-radius: 50%; top: -2px; }
  .path-line::before { left: 0; } .path-line::after { right: 0; }
  .wire-badge { position: absolute; top: -18px; background: #f39c12; color: #000; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 900; }
  .sig-badge { position: absolute; bottom: -18px; color: #00d4ff; font-size: 10px; font-weight: bold; }
`;

const STORAGE_KEY = "conneks.data.v1";

type WireRecord = {
  signalType?: string; src_dwg?: string; src_loc1?: string; src_loc2?: string; src_dev?: string; src_conn?: string; src_port?: string;
  dst_dwg?: string; dst_loc1?: string; dst_loc2?: string; dst_dev?: string; dst_conn?: string; dst_port?: string;
  color?: string; remarks?: string; wireType?: string; len?: string; wireNumber?: string;
};

export default function App() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [rowData, setRowData] = useState<WireRecord[]>([]);
  const [history, setHistory] = useState<WireRecord[][]>([]);
  const [selectedCable, setSelectedCable] = useState<WireRecord | null>(null);
  const [searchText, setSearchText] = useState("");

  const [printLoc1, setPrintLoc1] = useState(true);
  const [printLoc2, setPrintLoc2] = useState(true);
  const [printPort, setPrintPort] = useState(true);

  const [showSignal, setShowSignal] = useState(true);
  const [showDwg, setShowDwg] = useState(true);
  const [showLoc1, setShowLoc1] = useState(true);
  const [showLoc2, setShowLoc2] = useState(true);
  const [showConn, setShowConn] = useState(true);
  const [showPort, setShowPort] = useState(true);
  const [showLen, setShowLen] = useState(true);
  const [showCblType, setShowCblType] = useState(true);
  const [showColor, setShowColor] = useState(true);
  const [showRemarks, setShowRemarks] = useState(true);

  const gridRef = useRef<AgGridReact<WireRecord>>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) setRowData(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rowData));
  }, [rowData]);

  const saveHistory = useCallback(() => {
    setHistory(prev => [...prev.slice(-19), JSON.parse(JSON.stringify(rowData))]);
  }, [rowData]);

  const handleUndo = useCallback(() => {
    setHistory(prev => {
      if (prev.length === 0) return prev;
      setRowData(prev[prev.length - 1]); 
      return prev.slice(0, -1);
    });
  }, []);

  const handleSelectAll = (val: boolean) => {
    setShowSignal(val); setShowDwg(val); setShowLoc1(val); setShowLoc2(val);
    setShowConn(val); setShowPort(val); setShowLen(val); setShowCblType(val);
    setShowColor(val); setShowRemarks(val);
  };

  const isAllSelected = showSignal && showDwg && showLoc1 && showLoc2 && showConn && showPort && showLen && showCblType && showColor && showRemarks;

  const handleDelete = useCallback(() => {
    const selectedNodes = gridRef.current?.api.getSelectedNodes();
    if (!selectedNodes || selectedNodes.length === 0) return;
    if (window.confirm(`Delete ${selectedNodes.length} selected record(s)?`)) {
      saveHistory();
      const selectedData = selectedNodes.map(node => node.data);
      setRowData(prev => prev.filter(row => !selectedData.includes(row)));
      setSelectedCable(null);
    }
  }, [saveHistory]);

  const isExternalFilterPresent = useCallback(() => searchText !== "", [searchText]);

  const doesExternalFilterPass = useCallback((node: IRowNode<WireRecord>) => {
    if (!searchText || !node.data) return true;
    const regexStr = searchText.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');               
    const regex = new RegExp(`^${regexStr}$`, 'i');
    const fuzzyRegex = new RegExp(regexStr, 'i');
    return Object.values(node.data).some(val => {
      const sVal = String(val || "");
      return (searchText.includes('*') || searchText.includes('?')) ? regex.test(sVal) : fuzzyRegex.test(sVal);
    });
  }, [searchText]);

  const colDefs = useMemo<(ColDef | ColGroupDef)[]>(() => [
    { field: "wireNumber", headerName: "WIRE#", width: 90, pinned: "left" },
    { field: "signalType", headerName: "SIG", width: 80, hide: !showSignal, cellEditor: 'agSelectCellEditor', cellEditorParams: { values: SIGNAL_TYPES } },
    {
      headerName: "A SIDE", headerClass: 'a-side-header',
      children: [
        { field: "src_dwg", headerName: "PAGE#", width: 75, hide: !showDwg },
        { field: "src_loc1", headerName: "LOC 1", width: 90, hide: !showLoc1 },
        { field: "src_loc2", headerName: "LOC 2", width: 90, hide: !showLoc2 },
        { field: "src_dev", headerName: "DEVICE", width: 120 },
        { field: "src_conn", headerName: "CONN", width: 90, hide: !showConn },
        { field: "src_port", headerName: "PORT", width: 85, hide: !showPort },
      ]
    },
    {
      headerName: "B SIDE", headerClass: 'b-side-header',
      children: [
        { field: "dst_dwg", headerName: "PAGE#", width: 75, hide: !showDwg },
        { field: "dst_loc1", headerName: "LOC 1", width: 90, hide: !showLoc1 },
        { field: "dst_loc2", headerName: "LOC 2", width: 90, hide: !showLoc2 },
        { field: "dst_dev", headerName: "DEVICE", width: 120 },
        { field: "dst_conn", headerName: "CONN", width: 90, hide: !showConn },
        { field: "dst_port", headerName: "PORT", width: 85, hide: !showPort },
      ]
    },
    { field: "len", headerName: "LEN", width: 75, hide: !showLen },
    { field: "wireType", headerName: "CBL TYPE", width: 100, hide: !showCblType },
    { field: "color", headerName: "COLOR", width: 80, hide: !showColor },
    { field: "remarks", headerName: "RMRKS", width: 110, hide: !showRemarks },
  ], [showSignal, showDwg, showLoc1, showLoc2, showConn, showPort, showLen, showCblType, showColor, showRemarks]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    saveHistory();
    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const allRows = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
      const markerIdx = allRows.findIndex(row => String(row[0] || "").toUpperCase().includes("RECORDS START"));
      if (markerIdx === -1) { alert("Marker not found in Column A."); return; }
      const translatedData: WireRecord[] = allRows.slice(markerIdx + 1)
        .map((row): WireRecord | null => {
          if (!row[1]) return null;
          return {
            wireNumber: String(row[1]), signalType: row[2],
            src_dwg: row[3], src_loc1: row[4], src_loc2: row[5], src_dev: row[6], src_conn: row[7], src_port: row[8],
            dst_dwg: row[10], dst_loc1: row[11], dst_loc2: row[12], dst_dev: row[13], dst_conn: row[14], dst_port: row[15],
            wireType: row[16], len: row[17], color: row[18], remarks: row[19]
          };
        }).filter((r): r is WireRecord => r !== null);
      setRowData(prev => [...prev, ...translatedData]);
    };
    reader.readAsBinaryString(file);
    e.target.value = ""; 
  };

  const buildLabelLine = (side: 'A' | 'B') => {
    if (!selectedCable) return "";
    const s = selectedCable;
    const loc1 = side === 'A' ? s.src_loc1 : s.dst_loc1;
    const loc2 = side === 'A' ? s.src_loc2 : s.dst_loc2;
    const dev = side === 'A' ? s.src_dev : s.dst_dev;
    const port = side === 'A' ? s.src_port : s.dst_port;
    return [s.wireNumber, printLoc1 ? loc1 : null, printLoc2 ? loc2 : null, dev, printPort ? port : null].filter(p => p).join(" ");
  };

  return (
    <>
      <style>{GRID_STYLES}</style> 
      <header style={{ height: '70px', backgroundColor: '#343a40', color: 'white', padding: '0 25px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0, minWidth: '180px' }}>CONNEKS <span style={{fontWeight: '300', fontSize: '1.1rem', opacity: 0.8}}>Utility</span></h2>

        {/* Dynamic Connection Path Visualizer */}
        <div className="path-visualizer">
          <div className="path-node">
            <span className="node-label">Source</span>
            <span className="node-value">{selectedCable?.src_dev || "---"}</span>
          </div>
          <div className="path-line-container">
            {selectedCable && <span className="wire-badge">{selectedCable.wireNumber}</span>}
            <div className="path-line"></div>
            {selectedCable && <span className="sig-badge">{selectedCable.signalType}</span>}
          </div>
          <div className="path-node">
            <span className="node-label">Destination</span>
            <span className="node-value">{selectedCable?.dst_dev || "---"}</span>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <input style={{padding: '8px', borderRadius: '4px', border: '1px solid #555', background: '#fff', width: '220px'}} placeholder="Search (use * wildcards)..." value={searchText} onChange={e => { setSearchText(e.target.value); gridRef.current?.api.onFilterChanged(); }} />
          <button className="btn btn-dark" onClick={handleUndo}>Undo</button>
          <button className="btn btn-primary" onClick={() => { saveHistory(); setRowData([...rowData, { wireNumber: `NEW-${rowData.length + 1}` }]); }}>+ Add</button>
          <button className="btn btn-dark" onClick={() => fileRef.current?.click()}>Import</button>
          <button className="btn btn-danger" onClick={handleDelete}>Delete</button>
          <input type="file" ref={fileRef} style={{display:'none'}} onChange={handleFileUpload} accept=".xlsx, .xls, .csv" />
        </div>
      </header>

      <div style={{ display: 'flex', height: 'calc(100vh - 70px)' }}> 
        <aside style={{ width: '280px', backgroundColor: 'white', borderRight: '1px solid #ddd', padding: '20px', overflowY: 'auto' }}>
          <div className="sidebar-section">
            <h4>Live Label Preview</h4>
            <div className="label-preview-container">
              {selectedCable ? <>{buildLabelLine('A')}<br/>{buildLabelLine('B')}<br/>{buildLabelLine('A')}<br/>{buildLabelLine('B')}</> : "Select a row..."}
            </div>
          </div>
          <div className="sidebar-section">
            <h4>Label Print Options</h4>
            <label className="checkbox-label"><input type="checkbox" checked={printLoc1} onChange={e => setPrintLoc1(e.target.checked)} /> Location 1</label>
            <label className="checkbox-label"><input type="checkbox" checked={printLoc2} onChange={e => setPrintLoc2(e.target.checked)} /> Location 2</label>
            <label className="checkbox-label"><input type="checkbox" checked={printPort} onChange={e => setPrintPort(e.target.checked)} /> Port</label>
          </div>
          <div className="sidebar-section">
            <h4>Show / Hide Columns</h4>
            <label className="checkbox-label" style={{fontWeight: 'bold', marginBottom: '12px', color: '#007bff'}}>
              <input type="checkbox" checked={isAllSelected} onChange={e => handleSelectAll(e.target.checked)} /> Select All
            </label>
            {[["Signal", showSignal, setShowSignal], ["Page", showDwg, setShowDwg], ["Loc 1", showLoc1, setShowLoc1], ["Loc 2", showLoc2, setShowLoc2], ["Conn", showConn, setShowConn], ["Port", showPort, setShowPort], ["Length", showLen, setShowLen], ["Cbl Type", showCblType, setShowCblType], ["Color", showColor, setShowColor], ["Remarks", showRemarks, setShowRemarks]].map(([label, val, set]: any) => (
              <label key={label} className="checkbox-label"><input type="checkbox" checked={val} onChange={e => set(e.target.checked)} /> {label}</label>
            ))}
          </div>
        </aside>
        <main style={{ flex: 1, padding: '10px' }}>
          <div className="ag-theme-balham" style={{ height: '100%', width: '100%' }}>
            <AgGridReact 
              ref={gridRef} 
              rowData={rowData} 
              columnDefs={colDefs} 
              defaultColDef={{ editable: true, resizable: true, sortable: true }}
              isExternalFilterPresent={isExternalFilterPresent} 
              doesExternalFilterPass={doesExternalFilterPass} 
              rowSelection="multiple" 
              onRowSelected={(e) => { const selected = e.api.getSelectedRows(); setSelectedCable(selected.length > 0 ? selected[0] : null); }} 
            />
          </div>
        </main>
      </div>
    </>
  );
}